require('dotenv').config();
const express = require('express');
const path = require('path');
const app = express();
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const cors = require('cors');
const dns = require('dns');

// Configure Node.js to use Google's Public DNS servers globally for this process
dns.setServers([
  '8.8.8.8', // Primary
  '8.8.4.4'  // Secondary
]);

const uri = process.env.MONGO_STR;

async function connectDB() {
  try {
    // 2. חיבור ל-MongoDB עם הגדרות כפויות
mongoose.connect(uri, {
    dbName: 'RealEstateAgentDB',
});

    console.log("✅ MongoDB connected");

            const dbName = mongoose.connection.name;
            console.log("--- בדיקת חיבור ל-DB ---");
            console.log("שם ה-Database הנוכחי בקוד:", dbName);
    
  } catch (err) {
    console.error("❌ MongoDB connection error:", err);
    process.exit(1);
  }
}

connectDB();


// Enable CORS for all routes
app.use(cors());
app.use(express.json());


app.use(express.static(path.join(__dirname, 'public')));
app.use(bodyParser.json()); // Parse request body JSON
app.use(bodyParser.urlencoded({ extended: true })); // Parse request body


const userRoutes = require('./api/router/UserRouter');
const propertyRoutes = require('./api/router/PropertyRouter');
const userPreferenceRoutes = require('./api/router/UserPreferenceRouter');
const userViewHistoryRoutes = require('./api/router/UserViewHistoryRouter');



// Use Routers as Middleware
app.use('/api/users', userRoutes);
app.use('/api/properties', propertyRoutes);
app.use('/api/userpreferences', userPreferenceRoutes);
app.use('/api/userViewHistory', userViewHistoryRoutes);



module.exports = app;
