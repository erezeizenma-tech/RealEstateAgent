const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
    firebaseUid: {
        type: String,
        required: true,
        unique: true
    },
    fullName: {
        type: String,
        required: true
    },
    email: {
        type: String,
        required: true,
        unique: true
    },
    role: {
        type: String,
        enum: ['user', 'agent', 'admin'], // Restricts value to these roles
        default: 'user'
    },
    profileImageUrl: {
        type: String,
        default: ""
    }
}, { 
    timestamps: true // Automatically generates createdAt and updatedAt ($date) fields
});

module.exports = mongoose.model('User', userSchema);
