const mongoose = require('mongoose');

const userViewHistorySchema = new mongoose.Schema({
    userId: { 
        type: mongoose.Schema.Types.ObjectId, 
        ref: 'User', 
        required: true, 
        unique: true 
    },
    // Array of viewed properties, ordered from newest to oldest
    history: [{
        propertyId: { type: mongoose.Schema.Types.ObjectId, ref: 'Property', required: true },
        viewedAt: { type: Date, default: Date.now }
    }]
}, { 
    collection: 'properties' // <-- Explicitly type your EXACT MongoDB collection name here!
});

module.exports = mongoose.model('userViewHistory', userViewHistorySchema);
