const mongoose = require('mongoose');

const UserPreferenceSchema = new mongoose.Schema({
    // Link directly to a User account ID
    userId: { 
        type: mongoose.Schema.Types.ObjectId, 
        ref: 'User', 
        required: true,
        unique: true // One preference profile per user
    },
    // Nested object storing their specific property filter settings
    savedFilters: {
        minPrice: { type: Number, default: 0 },
        maxPrice: { type: Number, default: 10000 },
        rooms: { type: Number, default: 1 }
    },
    updatedAt: { type: Date, default: Date.now }
}, { 
    timestamps: true // Automatically generates createdAt and updatedAt ($date) fields
});

module.exports = mongoose.model('UserPreference', UserPreferenceSchema);
