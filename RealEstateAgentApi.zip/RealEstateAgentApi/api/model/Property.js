const mongoose = require('mongoose');

const propertySchema = new mongoose.Schema({
    title: {
        type: String,
        required: true
    },
    description: {
        type: String,
        required: true
    },
    price: {
        type: Number,
        required: true
    },
    city: {
        type: String,
        required: true
    },
    address: {
        type: String,
        required: true
    },
    rooms: {
        type: Number,
        required: true
    },
    type: {
        type: String,
        required: true
    },
    forSale: {
        type: Boolean,
        default: true
    },
    ownerId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User', // References the User Model
        required: true
    },
    agentId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User', // References the User Model
        required: true
    },
    images: [{
        type: String // Array of image URLs
    }]
}, { 
    collection: 'properties' // <-- Explicitly type your EXACT MongoDB collection name here!
});

module.exports = mongoose.model('Property', propertySchema);
