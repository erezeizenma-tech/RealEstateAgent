const Property = require("../model/Property");


// יצירת נכס
exports.createProperty = async (req, res) => {
    try {

        // 🔎 חילוץ שדות ספציפיים מהבקשה
        const {
            title,
            description,
            price,
            city,
            address,
            rooms,
            type,
            forSale,
            ownerId,
            agentId,
            images
        } = req.body;

        // בדיקה בסיסית
        if (!title || !price || !city || !address || !rooms || !type || ownerId === undefined) {
            return res.status(400).json({ message: "Missing required fields" });
        }

        const newProperty = new Property({
            title,
            description,
            price,
            city,
            address,
            rooms,
            type,
            forSale,
            ownerId,
            agentId,
            images
        });

        await newProperty.save();

        res.status(201).json(newProperty);

    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};


/*
exports.getAllProperties = async (req, res) => {
    try {
        console.log("---GetAllproperties---");
        const properties = await Property.find({}); // ישלוף כעת מה-DB הנכון
        res.status(200).json(properties);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

*/
const mongoose = require('mongoose');

exports.getAllProperties = async (req, res) => {
    try {
        // 1. נבדוק לאיזה שם של Database אנחנו מחוברים כרגע
        const dbName = mongoose.connection.name;
        console.log("--- בדיקת חיבור ל-DB ---");
        console.log("שם ה-Database הנוכחי בקוד:", dbName);

        // 2. נשלוף את כל השמות של ה-Collections שקיימים באמת בתוך ה-DB הזה
        const collections = await mongoose.connection.db.listCollections().toArray();
        const collectionNames = collections.map(c => c.name);
        console.log("ה-Collections שקיימים באמת בתוך ה-DB הזה:", collectionNames);
        console.log("------------------------");

        // 3. שליפה ישירה ללא מודל בכלל (לפי שם האוסף המדויק)
        // תשנה את 'property' לשם האוסף האמיתי שלך אם גילית שהוא שונה מההדפסה למעלה
        //const directData = await mongoose.connection.db.collection('property').find({}).toArray();
        const directData = await Property.find({});

        res.status(200).json(
            directData
        );
    } catch (error) {
        console.log("-------------", error.message);
        res.status(500).json({ error: error.message });
    }
};


exports.getPropertiesByAgent = async (req, res) => {
    try {

        const { agentId } = req.params;

        const properties = await Property.find({ agentId })
            .populate("ownerId", "fullName email profileImageUrl")
            .populate("agentId", "fullName email profileImageUrl");

        res.json(properties);

    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

exports.getPropertiesByOwner = async (req, res) => {
    try {

        const { ownerId } = req.params;

        const properties = await Property.find({ ownerId })
            .populate("ownerId", "fullName email profileImageUrl")
            .populate("agentId", "fullName email profileImageUrl");

        res.json(properties);

    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};


// קבלת נכס לפי ID
exports.getPropertyById = async (req, res) => {
    try {

        const property = await Property.findById(req.params.id)
            .populate("ownerId", "fullName email profileImageUrl")
            .populate("agentId", "fullName email profileImageUrl");

        if (!property) {
            return res.status(404).json({ message: "Property not found" });
        }

        res.json(property);

    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};


// מחיקת נכס
exports.deleteProperty = async (req, res) => {
    try {

        const property = await Property.findByIdAndDelete(req.params.id);

        if (!property) {
            return res.status(404).json({ message: "Property not found" });
        }

        res.json({ message: "Property deleted successfully" });

    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
