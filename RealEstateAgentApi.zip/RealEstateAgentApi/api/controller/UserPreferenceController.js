const UserPreference = require('../model/UserPreference');

exports.saveUserPreferences = async (req, res) => {
    try {
        const { userId, minPrice, maxPrice, rooms } = req.body;

        // Find existing preferences by userId, or create a new document if missing
        const updatedPreferences = await UserPreference.findOneAndUpdate(
            { userId: userId },
            { 
                savedFilters: { minPrice, maxPrice, rooms },
                updatedAt: Date.now()
            },
            { new: true, upsert: true } // 'upsert: true' handles the save-or-update layer
        );

        res.status(200).json({ success: true, data: updatedPreferences });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
};
