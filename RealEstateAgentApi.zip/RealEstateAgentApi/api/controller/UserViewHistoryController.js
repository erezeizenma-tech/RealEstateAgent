const ViewHistory = require('../model/UserViewHistory');

exports.logPropertyView = async (req, res) => {
    try {
        const { userId, propertyId } = req.body;

        // 1. Pull existing history or initialize a blank document shell
        let userHistory = await userViewHistory.findOne({ userId });
        if (!userHistory) {
            userHistory = new userViewHistory({ userId, history: [] });
        }

        // 2. Remove the property if it already exists in their history array
        userHistory.history = userHistory.history.filter(
            item => item.propertyId.toString() !== propertyId
        );

        // 3. Add the property to the very front (index 0) of the array
        userHistory.history.unshift({ propertyId, viewedAt: new Date() });

        // 4. Cap history list length at 20 items total
        if (userHistory.history.length > 20) {
            userHistory.history = userHistory.history.slice(0, 20);
        }

        await userHistory.save();
        res.status(200).json({ success: true, message: "View logged successfully" });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
};

exports.getUserViewHistory = async (req, res) => {
    try {
        const { userId } = req.params;

        const data = await ViewHistory.findOne({ userId })
            .populate('history.propertyId'); // Injects full Property objects into the array

        if (!data) {
            return res.status(200).json([]); // Return empty list if no history exists yet
        }

        // Clean up the output structure to send a flat array of properties back to Android
        const flatHistory = data.history
            .filter(item => item.propertyId != null) // Filter out deleted properties
            .map(item => item.propertyId);

        res.status(200).json(flatHistory);
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
};

