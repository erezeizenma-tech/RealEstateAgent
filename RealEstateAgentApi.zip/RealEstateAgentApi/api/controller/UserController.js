const User = require("../model/User");

//const User = require("../model/User");
const jwt = require("jsonwebtoken");

const JWT_SECRET = process.env.ACCESS_TOKEN_SECRET;


// התחברות (אחרי שהמשתמש כבר אומת בפיירבייס בצד לקוח)
exports.login = async (req, res) => {
    try {

        const { firebaseUid } = req.body;

        if (!firebaseUid) {
            return res.status(400).json({ message: "firebaseUid required" });
        }

        // בדיקה אם המשתמש קיים במסד
        const user = await User.findOne({ firebaseUid });

        if (!user) {
            return res.status(404).json({ message: "User not found in DB" });
        }

        // יצירת JWT משלך
        const token = jwt.sign(
            {
                id: user._id,
                firebaseUid: user.firebaseUid,
                role: user.role
            },
            JWT_SECRET,
            { expiresIn: "1h" }
        );

        res.json({
            token,
            user
        });

    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

// יצירת משתמש לאחר הרשמה ב-Firebase
exports.createUser = async (req, res) => {
    try {

        const { firebaseUid, fullName, email, role, profileImageUrl } = req.body;

        // בדיקה אם המשתמש כבר קיים לפי firebaseUid
        const existingUser = await User.findOne({ firebaseUid });
        if (existingUser) {
            return res.status(400).json({ message: "User already exists" });
        }

        const user = new User({
            firebaseUid,
            fullName,
            email,
            role,
            profileImageUrl
        });

        await user.save();

        res.status(201).json(user);

    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};


// קבלת משתמש לפי firebaseUid
exports.getUserByFirebaseUid = async (req, res) => {
    try {

        const { firebaseUid } = req.params;

        const user = await User.findOne({ firebaseUid });

        if (!user) {
            return res.status(404).json({ message: "User not found" });
        }

        res.json(user);

    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};


// עדכון משתמש
exports.updateUser = async (req, res) => {
    try {

        const { firebaseUid } = req.params;

        const updatedUser = await User.findOneAndUpdate(
            { firebaseUid },
            req.body,
            { new: true }
        );

        if (!updatedUser) {
            return res.status(404).json({ message: "User not found" });
        }

        res.json(updatedUser);

    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
