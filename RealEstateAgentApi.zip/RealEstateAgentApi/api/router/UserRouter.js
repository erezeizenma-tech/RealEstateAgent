const express = require("express");
const router = express.Router();
const userController = require("../controller/UserController");

const authenticateJWT = require("../middleware");

router.post("/login", userController.login);
router.post("/", userController.createUser);

router.get("/:firebaseUid", authenticateJWT, userController.getUserByFirebaseUid);
router.put("/:firebaseUid", authenticateJWT, userController.updateUser);

module.exports = router;
