const express = require("express");
const router = express.Router();
const propertyController = require("../controller/PropertyController");

const authenticateJWT = require("../middleware");


router.get("/", propertyController.getAllProperties);
router.get("/:id", propertyController.getPropertyById);
router.get("/owner/:ownerId",authenticateJWT ,propertyController.getPropertiesByOwner);
router.get("/agent/:agentId",authenticateJWT, propertyController.getPropertiesByAgent);
router.post("/",authenticateJWT, propertyController.createProperty);
router.delete("/:id",authenticateJWT, propertyController.deleteProperty);

module.exports = router;
