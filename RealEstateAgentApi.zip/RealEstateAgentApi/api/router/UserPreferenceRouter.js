const express = require("express");
const router = express.Router();
const userPreferenceController = require("../controller/UserPreferenceController");

const authenticateJWT = require("../middleware");

router.post("/save", userPreferenceController.saveUserPreferences);

module.exports = router;
