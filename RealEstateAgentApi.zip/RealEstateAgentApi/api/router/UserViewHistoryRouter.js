const express = require("express");
const router = express.Router();
const userViewHistoryController = require("../controller/UserViewHistoryController");

const authenticateJWT = require("../middleware");

router.post("/logPropertyView", userViewHistoryController.logPropertyView);
router.post("/getUserViewHistory", userViewHistoryController.getUserViewHistory);

module.exports = router;
