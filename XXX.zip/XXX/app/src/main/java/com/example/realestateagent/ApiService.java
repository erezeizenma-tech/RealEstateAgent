package com.example.realestateagent;

import java.util.List;
import java.util.Map;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Path;
import retrofit2.http.QueryMap;

public interface ApiService {

    // Maps to: POST /api/properties
    @POST("api/properties/createProperty")
    Call<Property> createProperty(@Body Property property);

    // Maps to: GET /api/properties
    @GET("api/properties")
    Call<List<Property>> getAllProperties();

    // Maps to: GET /api/properties/search?city=Jerusalem&rooms=2
    @GET("api/properties/search")
    Call<List<Property>> searchProperties(@QueryMap Map<String, String> filters);

    // Maps to: POST /api/users
    @POST("api/users")
    Call<User> createUser(@Body User user);

    // Maps to: GET /api/users/:uid
    @GET("api/users/{uid}")
    Call<User> getUserByFirebaseUid(@Path("uid") String firebaseUid);

    // Maps to: PUT /api/users/:uid
    @PUT("api/users/{uid}")
    Call<User> updateUser(@Path("uid") String firebaseUid, @Body User user);

    @POST("/api/userpreferences")
    Call<Void> saveUserPreferences(@Body UserPreference userPreference);

    @POST("api/userViewHistory")
    Call<Void> logPropertyView(@Body UserHistoryRequest request);

    @GET("api/userViewHistory/{userId}")
    Call<List<Property>> getUserHistory(@Path("userId") String userId);

}
