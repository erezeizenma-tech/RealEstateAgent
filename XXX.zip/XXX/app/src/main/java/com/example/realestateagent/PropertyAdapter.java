package com.example.realestateagent;

import static androidx.core.content.ContextCompat.startActivity;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class PropertyAdapter extends RecyclerView.Adapter<PropertyAdapter.ViewHolder> {

    private Context context;
    private List<Property> propertyList;

    Call<Void> call;
    public PropertyAdapter() {
        // Keeps the constructor empty so you can initialize it without arguments
    }
    public PropertyAdapter(Context context, List<Property> propertyList) {
        this.context = context;
        this.propertyList = propertyList;
    }
    // 1. Declare the private listener variable
    private OnItemClickListener listener;

    // 2. DEFINE THE INTERFACE (This is what the compiler is missing)
    public interface OnItemClickListener {
        void onItemClick(Property property);
    }

    // 3. Add the public setter method
    public void setOnItemClickListener(OnItemClickListener listener) {
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_property, parent, false);

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int viewType) {
        Property property = propertyList.get(viewType);
        holder.title.setText(property.getTitle());
        holder.address.setText(property.getAddress());
        holder.price.setText(property.getCity());


        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String activeUserId = "69e3c7d876f8c800f4976aab"; // Pull from your user session context or SharedPreferences
                String clickedPropertyId = property.getId();

                // Initialize your custom request model object wrapper
                UserHistoryRequest payload = new UserHistoryRequest(activeUserId, clickedPropertyId);

                ApiService apiService = RetrofitClient.getApiService();

                // Execute the network queue tracking logic
                call = apiService.logPropertyView(payload);
                call.enqueue(new Callback<Void>() {
                    @Override
                    public void onResponse(Call<Void> call, Response<Void> response) {
                        if (response.isSuccessful()) {
                            Log.d("HISTORY_LOG", "View history updated successfully on Node.js server.");
                        }
                    }

                    @Override
                    public void onFailure(Call<Void> call, Throwable t) {
                        Log.e("HISTORY_LOG", "Failed to track view: " + t.getMessage());
                    }
                });
            }
        });

        // Use Glide to download and display the image dynamically
        /*
        Glide.with(holder.itemView.getContext())
                .load("xxx") // Pass your MongoDB image web address here
                .placeholder(R.drawable.ic_launcher_background) // Shows while loading
                .error(android.R.drawable.stat_notify_error) // Shows if link fails
                .into(holder.image); // Target view
*/
        //Glide.with(context).load(property.getImageUrl()).into(holder.image);
    }

    public void setList(List<Property> properties) {
        this.propertyList = properties;

        // מעדכן את ה-RecyclerView שנוספו נתונים חדשים ויש לרענן את המסך
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() { return propertyList.size(); }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView image;
        TextView title, address, price;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            image = itemView.findViewById(R.id.property_image);
            title = itemView.findViewById(R.id.property_title);
            address = itemView.findViewById(R.id.property_address);
            price = itemView.findViewById(R.id.property_price);
        }
    }
}
