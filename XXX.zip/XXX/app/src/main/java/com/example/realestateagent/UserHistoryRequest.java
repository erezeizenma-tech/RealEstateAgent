package com.example.realestateagent;

import com.google.gson.annotations.SerializedName;

public class UserHistoryRequest {

    @SerializedName("userId")
    private String userId;

    @SerializedName("propertyId")
    private String propertyId;

    // Constructor to easily instantiate the payload when a user clicks a row
    public UserHistoryRequest(String userId, String propertyId) {
        this.userId = userId;
        this.propertyId = propertyId;
    }

    // Getters and Setters (Required for Gson serialization layer)
    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getPropertyId() {
        return propertyId;
    }

    public void setPropertyId(String propertyId) {
        this.propertyId = propertyId;
    }
}
