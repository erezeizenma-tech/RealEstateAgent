package com.example.realestateagent;
import java.util.Date;

public class User {
    private String id; // Maps from _id.$oid
    private String firebaseUid;
    private String fullName;
    private String email;
    private String role;
    private String profileImageUrl;
    private Date createdAt; // Parsed from ISO date string
    private Date updatedAt; // Parsed from ISO date string
    private int v; // Maps from __v

    // Empty constructor required for Firebase / JSON Deserializers
    public User() {
    }

    // Full constructor
    public User(String id, String firebaseUid, String fullName, String email,
                String role, String profileImageUrl, Date createdAt, Date updatedAt, int v) {
        this.id = id;
        this.firebaseUid = firebaseUid;
        this.fullName = fullName;
        this.email = email;
        this.role = role;
        this.profileImageUrl = profileImageUrl;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
        this.v = v;
    }

    // Getters and Setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getFirebaseUid() { return firebaseUid; }
    public void setFirebaseUid(String firebaseUid) { this.firebaseUid = firebaseUid; }

    public String getFullName() { return fullName; }
    public void setFullName(String fullName) { this.fullName = fullName; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getRole() { return role; }
    public void setRole(String role) { this.role = role; }

    public String getProfileImageUrl() { return profileImageUrl; }
    public void setProfileImageUrl(String profileImageUrl) { this.profileImageUrl = profileImageUrl; }

    public Date getCreatedAt() { return createdAt; }
    public void setCreatedAt(Date createdAt) { this.createdAt = createdAt; }

    public Date getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(Date updatedAt) { this.updatedAt = updatedAt; }

    public int getV() { return v; }
    public void setV(int v) { this.v = v; }
}
