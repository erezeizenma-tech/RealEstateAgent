package com.example.realestateagent;
import com.google.gson.annotations.SerializedName;

public class SavedFilters {

    @SerializedName("minPrice")
    private double minPrice;

    @SerializedName("maxPrice")
    private double maxPrice;

    @SerializedName("rooms")
    private int rooms;

    // בנאי ריק (חובה עבור Gson)
    public SavedFilters() {}

    // בנאי נוח לשימוש קל
    public SavedFilters(double minPrice, double maxPrice, int rooms) {
        this.minPrice = minPrice;
        this.maxPrice = maxPrice;
        this.rooms = rooms;
    }

    // גטרים וסטרים
    public double getMinPrice() { return minPrice; }
    public void setMinPrice(double minPrice) { this.minPrice = minPrice; }

    public double getMaxPrice() { return maxPrice; }
    public void setMaxPrice(double maxPrice) { this.maxPrice = maxPrice; }

    public int getRooms() { return rooms; }
    public void setRooms(int rooms) { this.rooms = rooms; }
}

