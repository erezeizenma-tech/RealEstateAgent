package com.example.realestateagent;

import com.google.gson.annotations.SerializedName;

import java.lang.reflect.Array;

import java.util.List;


public class Property {
    private String _id;
    private String title;
    private String description;
    private double price;
    private String city;
    private String address;
    private int rooms;
    private String type;
    private boolean forSale;
    private String ownerId;
    private String agentId;
    private List<String> images;

    // Empty constructor required for Firebase / JSON Deserializers
    public Property() {
    }

    // Full constructor
    public Property(String id, String title, String description, double price, String city,
                    String address, int rooms, String type, boolean forSale,
                    String ownerId, String agentId, List<String> images) {
        this._id = id;
        this.title = title;
        this.description = description;
        this.price = price;
        this.city = city;
        this.address = address;
        this.rooms = rooms;
        this.type = type;
        this.forSale = forSale;
        this.ownerId = ownerId;
        this.agentId = agentId;
        this.images = images;
    }

    // Getters and Setters
    public String getId() { return this._id; }
    public void setId(String id) { this._id = id; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public double getPrice() { return price; }
    public void setPrice(double price) { this.price = price; }

    public String getCity() { return city; }
    public void setCity(String city) { this.city = city; }

    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }

    public int getRooms() { return rooms; }
    public void setRooms(int rooms) { this.rooms = rooms; }

    public String getType() { return type; }
    public void setType(String type) { this.type = type; }

    public boolean isForSale() { return forSale; }
    public void setForSale(boolean forSale) { this.forSale = forSale; }

    public String getOwnerId() { return ownerId; }
    public void setOwnerId(String ownerId) { this.ownerId = ownerId; }

    public String getAgentId() { return agentId; }
    public void setAgentId(String agentId) { this.agentId = agentId; }

    public List<String> getImages() { return images; }
    public void setImages(List<String> images) { this.images = images; }

    // ==========================================
    // INNER CLASS: MUST BE INSIDE PROPERTY CLASS
    // ==========================================
/*
    public static class MongoId {
        @SerializedName("$oid")
        private String oid;

        public String getOid() {
            return oid;
        }

        public void setOid(String oid) {
            this.oid = oid;
        }
    }

 */
}
