package com.example.realestateagent;
import com.google.gson.annotations.SerializedName;
import java.util.Date;

public class UserPreference {

    @SerializedName("_id") // המזהה האוטומטי ש-MongoDB מייצר
    private String id;

    @SerializedName("userId")
    private String userId;

    @SerializedName("savedFilters") // כאן אנחנו מחברים את האובייקט המקונן
    private SavedFilters savedFilters;

    @SerializedName("createdAt")
    private Date createdAt;

    @SerializedName("updatedAt")
    private Date updatedAt;

    // בנאי ריק
    public UserPreference() {}

    // בנאי נוח לשליחת עדכונים לשרת
    public UserPreference(String userId, SavedFilters savedFilters) {
        this.userId = userId;
        this.savedFilters = savedFilters;
    }

    // גטרים וסטרים
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getUserId() { return userId; }
    public void setUserId(String userId) { this.userId = userId; }

    public SavedFilters getSavedFilters() { return savedFilters; }
    public void setSavedFilters(SavedFilters savedFilters) { this.savedFilters = savedFilters; }

    public Date getCreatedAt() { return createdAt; }
    public Date getUpdatedAt() { return updatedAt; }
}
