package com.example.realestateagent;

import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.animation.ValueAnimator;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.animation.LinearInterpolator;
import android.widget.ImageView;
import androidx.appcompat.app.AppCompatActivity;

public class AnimationActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_animation); // Uses the same layout with R.id.ic_home

        final ImageView homeIcon = findViewById(R.id.ic_home);

        homeIcon.post(new Runnable() {
            @Override
            public void run() {
                // 1. Bring icon layout layer to the front
                homeIcon.bringToFront();

                // 2. Setup a continuous pulse (growing and shrinking) for the 10-second wait
                PropertyValuesHolder scaleX = PropertyValuesHolder.ofFloat("scaleX", 1.0f, 1.6f);
                PropertyValuesHolder scaleY = PropertyValuesHolder.ofFloat("scaleY", 1.0f, 1.6f);
                PropertyValuesHolder translationZ = PropertyValuesHolder.ofFloat("translationZ", 0f, 16f);

                ObjectAnimator pulseAnimation = ObjectAnimator.ofPropertyValuesHolder(
                        homeIcon, scaleX, scaleY, translationZ
                );

                pulseAnimation.setDuration(1500); // Time for one single pulse pulse cycle
                pulseAnimation.setRepeatMode(ValueAnimator.REVERSE);
                pulseAnimation.setRepeatCount(ValueAnimator.INFINITE); // Keep pulsing until page changes
                pulseAnimation.setInterpolator(new LinearInterpolator());
                pulseAnimation.start();
            }
        });

        // 3. Wait exactly 10 seconds (10,000 ms), then transition to the Main Activity
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent = new Intent(AnimationActivity.this, LoginActivity.class);
                startActivity(intent);

                // Finish SplashActivity so the user cannot press the back button to return to it
                finish();
            }
        }, 10000);
    }
}

