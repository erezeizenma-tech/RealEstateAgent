package com.example.realestateagent;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.auth.AuthResult;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class LoginActivity extends AppCompatActivity {

    private EditText emailInput, passwordInput;
    private Button guestButton, gotoRegisterButton, loginButton;
    private FirebaseAuth mAuth; // Better to define this at the top

    ApiService userApiService;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);


        try {
            // Use the global Application Context instead of 'this' (Activity context)
            Context appContext = getApplicationContext();

// Force manual configuration values (No JSON file required)
            FirebaseOptions options = new FirebaseOptions.Builder()
                    .setApiKey("AIzaSyA9rC64R-ew9RzJQW09HQt3z-igPqZtGiU")
                    .setApplicationId("1:339560732240:android:62d195a2424ce746286355")
                    .setProjectId("testfirebase-18458") // Match your firebase init project id
                    .build();

            // Check if it's already initialized to prevent double-initialization crashes
            if (FirebaseApp.getApps(appContext).isEmpty()) {
                FirebaseApp.initializeApp(appContext, options);
            }


            // Safely fetch the instance
            mAuth = FirebaseAuth.getInstance();
            //mAuth.useEmulator("10.0.2.2", 9099);

        } catch (Exception e) {
            // Prevents the app from crashing and logs the exact failure cause
            Log.e("FIREBASE_ERROR", "Initialization failed: " + e.getMessage());
        }
        // 1. אתחול Firebase עבור האפליקציה (חובה לפני קריאה ל-getInstance)
        //FirebaseApp.initializeApp(this);

        //mAuth = FirebaseAuth.getInstance();

        emailInput = findViewById(R.id.emailInput);
        passwordInput = findViewById(R.id.passwordInput);
        gotoRegisterButton = findViewById(R.id.goToRegisterButton);
        loginButton = findViewById(R.id.loginButton);
        guestButton = findViewById(R.id.btnGuest);

        // Redirect to login if already have an account
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = (emailInput != null && emailInput.getText() != null)
                        ? emailInput.getText().toString().trim()
                        : null;

                String password = (passwordInput != null && passwordInput.getText() != null)
                        ? passwordInput.getText().toString().trim()
                        : null;

                if (TextUtils.isEmpty(email)) {
                    if (email != null) {
                        emailInput.setError("This field cannot be empty!");
                        emailInput.requestFocus();
                    } else {
                        Toast.makeText(LoginActivity.this, "Email input is missing!", Toast.LENGTH_SHORT).show();
                    }
                }
                if (TextUtils.isEmpty(password)) {
                    if (email != null) {
                        passwordInput.setError("This field cannot be empty!");
                        passwordInput.requestFocus();
                    } else {
                        Toast.makeText(LoginActivity.this, "Password input is missing!", Toast.LENGTH_SHORT).show();
                    }
                }
                loginWithFirebase(email, password);
            }
        });

        // Redirect to login if already have an account
        gotoRegisterButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
                startActivity(intent);
                finish();
            }
        });
        // Go to Main as guest
        guestButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }

    private void loginWithFirebase(String email, String password) {
        mAuth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, task -> {
                    if (task.isSuccessful()) {
                        FirebaseUser user = mAuth.getCurrentUser();
                        if (user != null) {
                            fetchMongoData(user.getUid());
                        }
                    } else {
                        String message = task.getException().getMessage();
                        Log.e("AUTH_ERROR", "Creation failed: " + message );
                    }
                });
    }

    private void fetchMongoData(String uid) {
        Call<User> call = userApiService.getUserByFirebaseUid(uid);
        call.enqueue(new Callback<User>() {
            @Override
            public void onResponse(@NonNull Call<User> call, @NonNull Response<User> response) {
                if (response.isSuccessful() && response.body() != null) {
                    User profile = response.body();
                    Toast.makeText(LoginActivity.this, "Welcome " + profile.getFullName() + "!", Toast.LENGTH_LONG).show();
                    // Put your Intent logic here to navigate to your home/dashboard activity
                } else {
                    Toast.makeText(LoginActivity.this, "User profile not found.", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(@NonNull Call<User> call, @NonNull Throwable t) {
                Toast.makeText(LoginActivity.this, "MongoDB Fetch Failed: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}