package com.example.realestateagent;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link HomePage#newInstance} factory method to
 * create an instance of this fragment.
 */
public class HomePage extends Fragment {
    private RecyclerView recyclerView;
    private PropertyAdapter adapter; // Replace with your actual Adapter class

    Call<List<Property>> call;
    private List<Property> dataList = new ArrayList<>(); // Replace String with your data model

    public HomePage() {
        // Required empty public constructor
        // loadPropertiesFromMongoDB();
        ApiService apiService = RetrofitClient.getApiService();
        call = apiService.getAllProperties();
        call.enqueue(new Callback<List<Property>>() {
            @Override
            public void onResponse(Call<List<Property>> call, Response<List<Property>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    dataList = response.body();

                    updateUiWithProperties(dataList);

                    // Success! Loop through your data or update UI here
                    Log.d("API_SUCCESS", "First property title: " + dataList.get(0).getTitle());
                } else {
                    Log.e("API_ERROR", "Response Code: " + response.code());
                }
            }

            @Override
            public void onFailure(Call<List<Property>> call, Throwable t) {
                // Network error, timeout, or incorrect URL configuration
                Log.e("API_FAILURE", "Error: " + t.getMessage());
            }
        });
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_home_page, container, false);

        // Initialize RecyclerView
        recyclerView = view.findViewById(R.id.recyclerViewProperties);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        // Generate dummy data

        //dataList = new ArrayList<>();
/*
        for (int i = 1; i <= 20; i++)
        {
            Property prop = new Property();
            prop.setTitle("Property1");
            dataList.add(prop);
        }
*/
        // Set Adapter
        adapter = new PropertyAdapter(getContext(), dataList);
        recyclerView.setAdapter(adapter);


        // BIND THE ADAPTER CLICK EVENT TO START A NEW ACTIVITY
        adapter.setOnItemClickListener(new PropertyAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(Property property) {
                // 1. Create the Intent target pointing to your destination Activity class
                Intent intent = new Intent(requireContext(), PropertyActivity.class);

                // 2. Pass data payload metrics (like MongoDB strings) along with the navigation layer
                intent.putExtra("PROPERTY_ID", property.getId());
                intent.putExtra("PROPERTY_TITLE", property.getTitle());

                // 3. Fire the Intent stack navigation transition
                startActivity(intent);
            }
        });

        return view;
    }

    private void updateUiWithProperties(List<Property> properties) {
        // כאן אתה שם את הקוד שמציג את הדירות על המסך
        Log.d("API_SUCCESS", "יש לנו נתונים! כמות דירות: " + properties.size());

        // דוגמה: הכנסת הנתונים לאדפטר של ה-RecyclerView שלך
        adapter.setList(properties);
        //adapter.notifyDataSetChanged();
    }



    private void loadPropertiesFromMongoDB()
    {
        try {
            ApiService apiService = RetrofitClient.getApiService();

            // Queue the network request asynchronously
            Log.d("API_DEBUG", "1. עומד לבצע את קריאת הרשת");
            Call<List<Property>> call = apiService.getAllProperties();
            call.enqueue(new Callback<List<Property>>() {
                @Override
                public void onResponse(Call<List<Property>> call, Response<List<Property>> response) {
                    if (response.isSuccessful() && response.body() != null) {
                        dataList = response.body();
                        // Success! Loop through your data or update UI here
                        Log.d("API_SUCCESS", "First property title: " + dataList.get(0).getTitle());
                    } else {
                        Log.e("API_ERROR", "Response Code: " + response.code());
                    }
                }

                @Override
                public void onFailure(Call<List<Property>> call, Throwable t) {
                    // Network error, timeout, or incorrect URL configuration
                    Log.e("API_FAILURE", "Error: " + t.getMessage());
                }
            });
            Log.d("API_DEBUG", "2. שורה זו תתבצע מייד, לפני שהשרת בכלל יענה!");
        }
        catch (Exception e) {
            Log.e("CRITICAL_ERROR", "Initialization failed: " + e.getMessage(), e);
        }

    }
}