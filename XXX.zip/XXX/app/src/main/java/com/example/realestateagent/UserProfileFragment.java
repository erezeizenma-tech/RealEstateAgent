package com.example.realestateagent;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class UserProfileFragment extends Fragment {
    private TextView textFullName;
    private Button buttonLastView;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_user_profile, container, false);

        // Initialize your UI elements using the inflated view
        textFullName = view.findViewById(R.id.textProfileTFullname);
        buttonLastView = view.findViewById(R.id.buttonLastView);

        // Set up click listeners or logic
        buttonLastView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getContext(), "Button Clicked inside Fragment!", Toast.LENGTH_SHORT).show();
            }
        });
        return view;
    }
}